
import re

WEAK_PASSWORDS = {
    "password", "123456", "123456789", "qwerty", "abc123",
    "letmein", "admin", "welcome", "iloveyou", "monkey"
}

def score_length(pw):
    length = len(pw)
    if length < 8:
        return 0, "Increase length to at least 12 characters."
    elif 8 <= length < 12:
        return 10, "Longer passwords improve security."
    elif 12 <= length < 16:
        return 20, ""
    else:
        return 25, ""

def score_complexity(pw):
    score = 0
    tips = []
    if re.search(r"[A-Z]", pw):
        score += 8
    else:
        tips.append("Add uppercase letters.")

    if re.search(r"[a-z]", pw):
        score += 8
    else:
        tips.append("Add lowercase letters.")

    if re.search(r"[0-9]", pw):
        score += 8
    else:
        tips.append("Add numbers.")

    if re.search(r"[^A-Za-z0-9]", pw):
        score += 8
    else:
        tips.append("Add special characters.")

    return score, tips

def detect_patterns(pw):
    tips = []
    penalty = 0

    if re.search(r"(.)\1{2,}", pw):
        penalty += 10
        tips.append("Avoid repeating characters.")

    if re.search(r"123|234|345|abc|bcd|cde", pw.lower()):
        penalty += 10
        tips.append("Avoid sequential patterns.")

    return penalty, tips

def check_dictionary(pw):
    if pw.lower() in WEAK_PASSWORDS:
        return 20, ["Password matches known weak passwords."]
    return 0, []

def evaluate_password(password):
    total = 0
    recommendations = []

    length_score, length_tip = score_length(password)
    total += length_score
    if length_tip:
        recommendations.append(length_tip)

    complexity_score, complexity_tips = score_complexity(password)
    total += complexity_score
    recommendations.extend(complexity_tips)

    pattern_penalty, pattern_tips = detect_patterns(password)
    total -= pattern_penalty
    recommendations.extend(pattern_tips)

    dict_penalty, dict_tips = check_dictionary(password)
    total -= dict_penalty
    recommendations.extend(dict_tips)

    total = max(0, min(total, 100))

    if total < 35:
        rating = "Weak"
    elif 35 <= total < 70:
        rating = "Moderate"
    else:
        rating = "Strong"

    return total, rating, recommendations

if __name__ == "__main__":
    pw = input("Enter password to test: ")
    score, rating, tips = evaluate_password(pw)

    print("\nPassword Strength Report")
    print("------------------------")
    print(f"Score: {score}/100")
    print(f"Rating: {rating}")

    if tips:
        print("\nRecommendations:")
        for t in tips:
            print(f"- {t}")
    else:
        print("No recommendations. Password looks solid.")
